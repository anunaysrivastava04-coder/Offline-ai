// -*- mode:c++;indent-tabs-mode:nil;c-basic-offset:4;coding:utf-8 -*-
// vi: set et ft=cpp ts=4 sts=4 sw=4 fenc=utf-8 :vi
//
// Copyright 2026 Mozilla.ai
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// ProgressCallback — prints a line on stderr before and after each tool
// call, and with -v a preview of the result. Model and tool text is
// escaped: under --yes these lines are the only record of a call.
//

#pragma once

#include "callbacks.h"
#include "tool_result.h"

#include "server_tools_adapter.h"  // printable_arguments
#include "util.h"

#include <cstdio>
#include <string>

namespace agentfile {

class ProgressCallback : public agent_cpp::Callback {
    bool verbose_;
    bool running_ = false;  // false after a declined confirmation

  public:
    explicit ProgressCallback(bool verbose = false) : verbose_(verbose) {}

    // Reasoning is commentary, not answer: show it dimmed on stderr and
    // keep stdout for the final result only.
    void after_llm_call(common_chat_msg &parsed_msg) override {
        if (!parsed_msg.reasoning_content.empty()) {
            std::fprintf(stderr, "%s[think] %s%s\n", dim(),
                         terminal_text(parsed_msg.reasoning_content,
                                       /*keep_newlines=*/true)
                             .c_str(),
                         dim_off());
        }
    }

    void before_tool_execution(std::string &tool_name,
                               std::string &arguments) override {
        running_ = true;
        std::fprintf(stderr, "%s[tool: %s %s]%s\n", dim(),
                     terminal_text(tool_name).c_str(),
                     printable_arguments(arguments).c_str(), dim_off());
    }

    void after_tool_execution(std::string &tool_name,
                              agent_cpp::ToolResult &result) override {
        if (!running_) return;  // declined: nothing ran
        running_ = false;
        if (result.has_error()) {
            std::fprintf(stderr, "%s[tool: %s -> error: %s]%s\n", dim(),
                         terminal_text(tool_name).c_str(),
                         terminal_text(result.error().message).c_str(),
                         dim_off());
        } else {
            const auto &out = result.output();
            std::fprintf(stderr, "%s[tool: %s -> %zu bytes]%s\n", dim(),
                         terminal_text(tool_name).c_str(), out.size(),
                         dim_off());
            if (verbose_ && !out.empty()) {
                constexpr size_t kPreview = 512;
                std::fprintf(stderr, "%s  %s%s%s\n", dim(),
                             terminal_text(out.substr(0, kPreview),
                                           /*keep_newlines=*/true)
                                 .c_str(),
                             out.size() > kPreview ? "…" : "", dim_off());
            }
        }
    }
};

} // namespace agentfile
