@echo off
setlocal enabledelayedexpansion
:: Compiles distributable DLL for AMD GPU support (TinyBLAS + ROCm HIP)
::
:: The artifact will depend on amdhip64.dll, hipblas.dll, and rocblas.dll
:: from the AMD ROCm HIP SDK installation.
::
:: Usage:
::   llamafile\rocm.bat              Build with TinyBLAS (default)
::   llamafile\rocm.bat --clean      Clean and rebuild
::   llamafile\rocm.bat --output X   Specify output path
::
:: Output: ggml-rocm.dll in the repo root (default)

:: -------- directories --------
:: Capture %~dp0 BEFORE any goto (goto corrupts %~dp0 in batch)
for %%I in ("%~dp0.") do set "LLAMAFILE_DIR=%%~fI"
for %%I in ("%~dp0..") do set "REPO_DIR=%%~fI"

:: -------- parse arguments --------
set "CLEAN=0"
set "OUTPUT="

:parse_args
if "%~1"=="" goto done_args
if /i "%~1"=="--clean"  (set "CLEAN=1"     & shift & goto parse_args)
if /i "%~1"=="--output" (set "OUTPUT=%~2"   & shift & shift & goto parse_args)
if /i "%~1"=="--help" (
    echo Usage: rocm.bat [--clean] [--output PATH]
    exit /b 0
)
echo Unknown option: %~1
exit /b 1
:done_args

:: -------- find Visual Studio / Build Tools --------
where cl >nul 2>&1
if errorlevel 1 (
    set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
    if not exist "!VSWHERE!" (
        echo Error: cl.exe not found in PATH and vswhere.exe not found
        echo Please run from a Visual Studio Developer Command Prompt
        exit /b 1
    )
    for /f "usebackq tokens=*" %%i in (`"!VSWHERE!" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do (
        set "VS_PATH=%%i"
    )
    if not defined VS_PATH (
        echo Error: Visual Studio with C++ tools not found
        exit /b 1
    )
    call "!VS_PATH!\VC\Auxiliary\Build\vcvarsall.bat" x64
)

set "LLAMA_CPP_DIR=%REPO_DIR%\llama.cpp"
set "GGML_CUDA_DIR=%LLAMA_CPP_DIR%\ggml\src\ggml-cuda"
set "GGML_SRC_DIR=%LLAMA_CPP_DIR%\ggml\src"
set "GGML_INC_DIR=%LLAMA_CPP_DIR%\ggml\include"

if not exist "%GGML_CUDA_DIR%" (
    echo Error: CUDA source directory not found: %GGML_CUDA_DIR%
    exit /b 1
)

:: -------- build configuration --------
set "BUILD_DIR=%USERPROFILE%\.cache\llamafile-rocm-build"
if "%OUTPUT%"=="" set "OUTPUT=%REPO_DIR%\ggml-rocm.dll"

:: -------- clean --------
if "%CLEAN%"=="1" (
    if exist "%BUILD_DIR%" (
        echo Cleaning build directory...
        rmdir /s /q "%BUILD_DIR%"
    )
)
if not exist "%BUILD_DIR%" mkdir "%BUILD_DIR%"

:: -------- find HIP compiler --------
:: Check HIP_PATH - try auto-detect if not set
if not defined HIP_PATH (
    for /d %%d in ("C:\Program Files\AMD\ROCm\*") do (
        if exist "%%d\bin\clang++.exe" set "HIP_PATH=%%d"
    )
)
if not defined HIP_PATH (
    echo Error: HIP_PATH not set and ROCm not found in default location
    echo Please install AMD ROCm HIP SDK and set HIP_PATH
    exit /b 1
)
set "HIPCC=%HIP_PATH%\bin\clang++.exe"
if not exist "%HIPCC%" (
    echo Error: clang++.exe not found at %HIPCC%
    exit /b 1
)

:: -------- AMD GPU architecture targets --------
:: gfx906:  Vega 20 (Radeon VII, MI50)
:: gfx942:  CDNA3 (AMD Instinct MI300X/MI300A)
:: gfx1030: RDNA2 (RX 6900 XT, RX 6800 series)
:: gfx1031: RDNA2 (RX 6700 series)
:: gfx1032: RDNA2 (RX 6600 series)
:: gfx1100: RDNA3 (RX 7900 XTX, RX 7900 XT)
:: gfx1101: RDNA3 (RX 7800 series)
:: gfx1102: RDNA3 (RX 7600 series)
:: gfx1103: RDNA3 (RX 7000 mobile)
:: ARCH_FLAGS can be overridden via the OFFLOAD_ARCH env var, e.g.
::   set "OFFLOAD_ARCH=--offload-arch=gfx942" ^& llamafile\rocm.bat  (single-arch fast build)
if defined OFFLOAD_ARCH (
    set "ARCH_FLAGS=%OFFLOAD_ARCH%"
) else (
    set "ARCH_FLAGS="
    set "ARCH_FLAGS=!ARCH_FLAGS! --offload-arch=gfx906"
    set "ARCH_FLAGS=!ARCH_FLAGS! --offload-arch=gfx942"
    set "ARCH_FLAGS=!ARCH_FLAGS! --offload-arch=gfx1030"
    set "ARCH_FLAGS=!ARCH_FLAGS! --offload-arch=gfx1031"
    set "ARCH_FLAGS=!ARCH_FLAGS! --offload-arch=gfx1032"
    set "ARCH_FLAGS=!ARCH_FLAGS! --offload-arch=gfx1100"
    set "ARCH_FLAGS=!ARCH_FLAGS! --offload-arch=gfx1101"
    set "ARCH_FLAGS=!ARCH_FLAGS! --offload-arch=gfx1102"
    set "ARCH_FLAGS=!ARCH_FLAGS! --offload-arch=gfx1103"
)

:: -------- copy TinyBLAS files --------
copy /y "%LLAMAFILE_DIR%\tinyblas.h"       "%BUILD_DIR%\" >nul
copy /y "%LLAMAFILE_DIR%\tinyblas.cu"      "%BUILD_DIR%\" >nul
copy /y "%LLAMAFILE_DIR%\tinyblas-compat.h" "%BUILD_DIR%\" >nul

:: -------- common HIP compiler flags --------
set "COMMON_FLAGS=-x hip -O2 -ffast-math -std=c++17"
set "COMMON_FLAGS=%COMMON_FLAGS% --gpu-max-threads-per-block=1024"
set "COMMON_FLAGS=%COMMON_FLAGS% -Wno-ignored-attributes -Wno-nested-anon-types"
set "COMMON_FLAGS=%COMMON_FLAGS% -I%BUILD_DIR% -I%GGML_INC_DIR% -I%GGML_SRC_DIR% -I%GGML_CUDA_DIR%"
set "COMMON_FLAGS=%COMMON_FLAGS% -I"%HIP_PATH%\include""
set "COMMON_FLAGS=%COMMON_FLAGS% -DNDEBUG -DGGML_BUILD=1 -DGGML_SHARED=1 -DGGML_BACKEND_SHARED=1 -DGGML_BACKEND_BUILD=1 -DGGML_MULTIPLATFORM"
set "COMMON_FLAGS=%COMMON_FLAGS% -DGGML_HIP_GRAPHS=1"
set "COMMON_FLAGS=%COMMON_FLAGS% -DGGML_USE_HIP=1 -DGGML_USE_TINYBLAS=1 -DGGML_HIP_NO_VMM=1 -D__HIP_PLATFORM_AMD__"

:: fattn.cu gates every K-V combination on a GGML_CUDA_FA_<K>_<V> macro that
:: must be defined to 0 or 1 for all of them (since b11100; upstream emits them
:: from ggml_cuda_fattn_vec_instances() in ggml/cmake/common.cmake). Selecting
:: template-instance files is no longer enough -- an undefined macro is a hard
:: error in the if constexpr. Keep this list and the default combinations in
:: sync with FA_TYPES / FA_DEFAULT_COMBINATIONS in llamafile/build-functions.sh.
:: (The informational GGML_CUDA_FA_QUANTS string macro is #ifdef-guarded and is
:: not set here, to avoid quoting it through cmd.)
set "FA_TYPES=Q4_0 Q4_1 Q5_0 Q5_1 Q8_0 BF16 F16"
set "FA_COMBINATIONS=Q4_0-Q4_0 Q8_0-Q8_0 F16-F16 BF16-BF16"
for %%v in (%FA_TYPES%) do for %%k in (%FA_TYPES%) do (
    set "FA_COMPILED=0"
    for %%c in (!FA_COMBINATIONS!) do if /i "%%c"=="%%k-%%v" set "FA_COMPILED=1"
    set "COMMON_FLAGS=!COMMON_FLAGS! -DGGML_CUDA_FA_%%k_%%v=!FA_COMPILED!"
)
:: --offload-compress shrinks the fat binary (mirrors rocm.sh / #995); requires a
:: recent ROCm HIP SDK -- drop this flag if your clang++ rejects it
set "COMMON_FLAGS=%COMMON_FLAGS% --offload-compress"

:: -------- extract GGML version --------
set "GGML_VERSION=unknown"
set "GGML_COMMIT=unknown"
set "CMAKE_FILE=%LLAMA_CPP_DIR%\ggml\CMakeLists.txt"
if exist "%CMAKE_FILE%" (
    for /f "tokens=2 delims=()" %%a in ('findstr /c:"set(GGML_VERSION_MAJOR" "%CMAKE_FILE%"') do (
        for /f "tokens=2" %%v in ("%%a") do set "GGML_VER_MAJOR=%%v"
    )
    for /f "tokens=2 delims=()" %%a in ('findstr /c:"set(GGML_VERSION_MINOR" "%CMAKE_FILE%"') do (
        for /f "tokens=2" %%v in ("%%a") do set "GGML_VER_MINOR=%%v"
    )
    for /f "tokens=2 delims=()" %%a in ('findstr /c:"set(GGML_VERSION_PATCH" "%CMAKE_FILE%"') do (
        for /f "tokens=2" %%v in ("%%a") do set "GGML_VER_PATCH=%%v"
    )
    set "GGML_VERSION=!GGML_VER_MAJOR!.!GGML_VER_MINOR!.!GGML_VER_PATCH!"
)
pushd "%LLAMA_CPP_DIR%\ggml" 2>nul && (
    for /f %%h in ('git rev-parse --short HEAD 2^>nul') do set "GGML_COMMIT=%%h"
    popd
)

echo Building ggml-rocm.dll with TinyBLAS...
echo   Version: !GGML_VERSION! (commit: !GGML_COMMIT!)
echo   Source:  %GGML_CUDA_DIR%
echo   Output:  %OUTPUT%
echo   Build:   %BUILD_DIR%
echo   HIP:     %HIP_PATH%
echo.

:: -------- collect and compile .cu sources --------
set "OBJ_FILES="
set /a COUNT=0
set /a COMPILED=0

:: TinyBLAS source
set /a COUNT+=1
set "OBJ=%BUILD_DIR%\tinyblas.obj"
set "SRC=%BUILD_DIR%\tinyblas.cu"
if not exist "!OBJ!" (
    echo [!COUNT!] Compiling: tinyblas.cu
    "%HIPCC%" -c %ARCH_FLAGS% %COMMON_FLAGS% -o "!OBJ!" "!SRC!"
    if errorlevel 1 (echo Error compiling tinyblas.cu & exit /b 1)
    set /a COMPILED+=1
) else (
    echo [!COUNT!] Skipping: tinyblas.cu (up to date^)
)
set "OBJ_FILES=!OBJ_FILES! "!OBJ!""

:: Main CUDA/HIP sources
for %%f in ("%GGML_CUDA_DIR%\*.cu") do (
    set /a COUNT+=1
    set "BASE=%%~nf"
    set "OBJ=%BUILD_DIR%\!BASE!.obj"
    set "SRC=%%f"
    if not exist "!OBJ!" (
        echo [!COUNT!] Compiling: !BASE!.cu
        "%HIPCC%" -c %ARCH_FLAGS% %COMMON_FLAGS% -o "!OBJ!" "!SRC!"
        if errorlevel 1 (echo Error compiling !BASE!.cu & exit /b 1)
        set /a COMPILED+=1
    ) else (
        echo [!COUNT!] Skipping: !BASE!.cu (up to date^)
    )
    set "OBJ_FILES=!OBJ_FILES! "!OBJ!""
)

:: Template-instances sources (mirror rocm.sh collect_gpu_sources: include all
:: fattn-mma / fattn-tile / mmf / mmq instances, but only the 4 default fattn-vec
:: quant combos -- f16-f16, q4_0-q4_0, q8_0-q8_0, bf16-bf16 -- to match upstream
:: CMake defaults and keep the DLL size down)
for %%f in (
    "%GGML_CUDA_DIR%\template-instances\fattn-mma-*.cu"
    "%GGML_CUDA_DIR%\template-instances\fattn-tile-*.cu"
    "%GGML_CUDA_DIR%\template-instances\mmf-*.cu"
    "%GGML_CUDA_DIR%\template-instances\mmq-*.cu"
    "%GGML_CUDA_DIR%\template-instances\fattn-vec-instance-f16-f16.cu"
    "%GGML_CUDA_DIR%\template-instances\fattn-vec-instance-q4_0-q4_0.cu"
    "%GGML_CUDA_DIR%\template-instances\fattn-vec-instance-q8_0-q8_0.cu"
    "%GGML_CUDA_DIR%\template-instances\fattn-vec-instance-bf16-bf16.cu"
) do (
    if exist "%%f" (
        set /a COUNT+=1
        set "BASE=%%~nf"
        set "OBJ=%BUILD_DIR%\ti-!BASE!.obj"
        set "SRC=%%f"
        if not exist "!OBJ!" (
            echo [!COUNT!] Compiling: ti-!BASE!.cu
            "%HIPCC%" -c %ARCH_FLAGS% %COMMON_FLAGS% -o "!OBJ!" "!SRC!"
            if errorlevel 1 (echo Error compiling ti-!BASE!.cu & exit /b 1)
            set /a COMPILED+=1
        ) else (
            echo [!COUNT!] Skipping: ti-!BASE!.cu (up to date^)
        )
        set "OBJ_FILES=!OBJ_FILES! "!OBJ!""
    )
)

echo.
echo Compiled %COMPILED% of %COUNT% .cu files (rest were up to date)
echo.

:: -------- compile core GGML sources with host compiler --------
echo Compiling core GGML sources...

set "HOST_FLAGS=/nologo /EHsc /O2 /GR /MT /Zc:preprocessor /DNDEBUG"
set "HOST_FLAGS=%HOST_FLAGS% /DGGML_BUILD=1 /DGGML_SHARED=1 /DGGML_BACKEND_SHARED=1 /DGGML_BACKEND_BUILD=1 /DGGML_MULTIPLATFORM"
set "HOST_FLAGS=%HOST_FLAGS% /DGGML_VERSION=\"!GGML_VERSION!\" /DGGML_COMMIT=\"!GGML_COMMIT!\""
set "HOST_FLAGS=%HOST_FLAGS% /I"%GGML_INC_DIR%" /I"%GGML_SRC_DIR%""

:: C sources
for %%f in (ggml.c ggml-alloc.c ggml-quants.c) do (
    set "SRC=%GGML_SRC_DIR%\%%f"
    set "BASE=%%~nf"
    set "OBJ=%BUILD_DIR%\ggml-core-!BASE!.obj"
    if not exist "!OBJ!" (
        echo   Compiling: %%f
        cl /c %HOST_FLAGS% /Fo"!OBJ!" "!SRC!"
        if errorlevel 1 (echo Error compiling %%f & exit /b 1)
    ) else (
        echo   Skipping: %%f (up to date^)
    )
)

:: C++ sources
for %%f in (ggml-backend.cpp ggml-backend-meta.cpp ggml-threading.cpp) do (
    set "SRC=%GGML_SRC_DIR%\%%f"
    set "BASE=%%~nf"
    set "OBJ=%BUILD_DIR%\ggml-core-!BASE!.obj"
    if not exist "!OBJ!" (
        echo   Compiling: %%f
        cl /c %HOST_FLAGS% /std:c++17 /Fo"!OBJ!" "!SRC!"
        if errorlevel 1 (echo Error compiling %%f & exit /b 1)
    ) else (
        echo   Skipping: %%f (up to date^)
    )
)

echo.

:: -------- link --------
echo Linking ggml-rocm.dll...
:: Collect all .obj files into a response file (command line too long for cmd.exe)
set "LINK_RSP=%BUILD_DIR%\link_objects.rsp"
type nul > "%LINK_RSP%"
for %%f in ("%BUILD_DIR%\*.obj") do (
    set "OBJPATH=%%f"
    echo "!OBJPATH:\=/!">> "%LINK_RSP%"
)
"%HIPCC%" -shared %ARCH_FLAGS% -o "%OUTPUT%" @"%LINK_RSP%" -L"%HIP_PATH%\lib" "%HIP_PATH%\lib\libhipblas.dll.a" "%HIP_PATH%\lib\rocblas.lib" "%HIP_PATH%\lib\amdhip64.lib"
if errorlevel 1 (
    echo Error: linking failed
    exit /b 1
)

echo.
echo Successfully built: %OUTPUT%
for %%f in ("%OUTPUT%") do echo   Size: %%~zf bytes
echo.

endlocal
